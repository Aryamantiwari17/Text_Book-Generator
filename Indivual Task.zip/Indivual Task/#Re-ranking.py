#Re-ranking 
from sklearn.metrics.pairwise import cosine_similarity

def rerank_documents(query, documents):
    query_embedding = sbert_model.encode([query])[0]
    doc_embeddings = sbert_model.encode(documents)
    similarities = cosine_similarity([query_embedding], doc_embeddings)[0]
    ranked_indices = np.argsort(similarities)[::-1]
    return [documents[i] for i in ranked_indices]
