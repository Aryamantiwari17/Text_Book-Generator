#Question Answering
from google.generativeai.types import GenerationConfig
from google.generativeai.types import GenerationConfig, SafetySettingDict, HarmCategory, HarmBlockThreshold
import google.generativeai as genai

def initialize_model():
    model = genai.GenerativeModel('gemini-pro')
    config = GenerationConfig(
        temperature=0.2,  # Slightly increased for more creative responses
        top_p=0.95,
        top_k=40,
        candidate_count=1,
        max_output_tokens=8192,  # Increased to allow for longer answers
    )
    safety_settings = [
        SafetySettingDict({
            "category": HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
            "threshold": HarmBlockThreshold.BLOCK_ONLY_HIGH
        }),
        SafetySettingDict({
            "category": HarmCategory.HARM_CATEGORY_HATE_SPEECH,
            "threshold": HarmBlockThreshold.BLOCK_ONLY_HIGH
        }),
        SafetySettingDict({
            "category": HarmCategory.HARM_CATEGORY_HARASSMENT,
            "threshold": HarmBlockThreshold.BLOCK_ONLY_HIGH
        }),
        SafetySettingDict({
            "category": HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
            "threshold": HarmBlockThreshold.BLOCK_ONLY_HIGH
        }),
    ]
    return model, config, safety_settings


def generate_content(model, config, safety_settings, prompt):
    try:
        response = model.generate_content(
            prompt,
            generation_config=config,
            safety_settings=safety_settings,
            stream=False
        )
        return response
    except Exception as e:
        print(f"Error generating content: {e}")
        return None

def answer_question(query, context):
    model, config, safety_settings = initialize_model()
    
    # Truncate context if it's too long
    max_context_length = 30000  # Adjust as needed, keeping in mind Gemini's token limit
    if len(context) > max_context_length:
        context = context[:max_context_length]
    
    prompt = f"""Given the following context, please provide a comprehensive answer to the question. If the context doesn't contain enough information, state that and provide the best possible answer based on the available information.

Context:
{context}

Question: {query}

Answer:"""

    try:
        response = generate_content(model, config, safety_settings, prompt)
        
        if response.prompt_feedback.block_reason:
            print(f"Response blocked. Reason: {response.prompt_feedback.block_reason}")
            return "The response was blocked due to safety concerns. Please try rephrasing your question."
        
        if response.candidates:
            if response.candidates[0].content.parts:
                answer = response.candidates[0].content.parts[0].text
                print(answer)
                print("\n" + "_"*80)
                return answer
            else:
                print("Response has no content parts.")
                return "No answer generated. The response had no content."
        else:
            print("No candidates in the response.")
            return "No answer generated. There were no response candidates."

    except Exception as e:
        print(f"Error generating answer: {e}")
        print(f"Error type: {type(e)}")
        print(f"Error args: {e.args}")
        return f"An error occurred: {str(e)}"