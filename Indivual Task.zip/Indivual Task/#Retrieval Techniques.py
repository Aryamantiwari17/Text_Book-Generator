#Retrieval Techniques 
import numpy as np
from pymilvus import MilvusClient, Collection, utility
def query_milvus(collection, query_vector, top_k=5):
    try:
        search_params = {
            "metric_type": "L2",
            "params": {"nprobe": 10},
        }

        results = collection.search(
            data=[query_vector.tolist()],
            anns_field="embedding",
            param=search_params,
            limit=top_k,
            output_fields=["text", "type"]
        )
        return results
    except Exception as e:
        print(f"Error in query_milvus: {e}")
        return []
    
    

def hybrid_retrieval(query, collection, top_k=50):
    try:
        # SBERT embedding
        sbert_embedding = sbert_model.encode(query)
        print(f"SBERT embedding shape: {sbert_embedding.shape}")
        sbert_results = query_milvus(collection, sbert_embedding, top_k)
        print(f"SBERT results: {len(sbert_results)}")

        # DPR embedding
        with torch.no_grad():
            question_embedding = dpr_question_encoder(**dpr_tokenizer(query, return_tensors="pt")).pooler_output
        dpr_embedding = question_embedding.squeeze().cpu().numpy()
        print(f"DPR embedding shape: {dpr_embedding.shape}")
        dpr_results = query_milvus(collection, dpr_embedding, top_k)
        print(f"DPR results: {len(dpr_results)}")

        # Combine results
        combined_results = []
        for hits in sbert_results + dpr_results:
            for hit in hits:
                combined_results.append((hit.entity.get('text'), hit.distance))

        # Remove duplicates and sort
        unique_results = list(set(combined_results))
        unique_results.sort(key=lambda x: x[1])

        return [text for text, _ in unique_results[:top_k]]
    except Exception as e:
        print(f"Error in hybrid_retrieval: {e}")
        return []

