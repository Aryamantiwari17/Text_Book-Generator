#Data Chunking :


import nltk

def chunk_text(text, tokenizer, max_chunk_size=6048, overlap=100):
    sentences = nltk.sent_tokenize(text)
    chunks = []
    current_chunk = []
    current_size = 0

    for sentence in sentences:
        sentence_tokens = tokenizer(sentence)
        sentence_length = len(sentence_tokens)

        if current_size + sentence_length > max_chunk_size:
            if current_chunk:
                chunks.append(' '.join(current_chunk))
            current_chunk = sentence_tokens
            current_size = sentence_length
        else:
            current_chunk.extend(sentence_tokens)
            current_size += sentence_length

        while current_size > max_chunk_size:
            chunks.append(' '.join(current_chunk[:max_chunk_size]))
            current_chunk = current_chunk[max_chunk_size-overlap:]
            current_size = len(current_chunk)

    if current_chunk:
        chunks.append(' '.join(current_chunk))

    return chunks

# Potential Repo: https://github.com/ nltk/nltk (NLTK library)