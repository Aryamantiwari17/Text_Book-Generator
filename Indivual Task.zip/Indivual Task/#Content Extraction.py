#Content Extraction

import PyPDF2

def extract_textbook_content(file_paths):
    all_text = []
    for pdf_path in file_paths:
        text = ""
        with open(pdf_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page in pdf_reader.pages:
                text += page.extract_text()
        all_text.append(text)
    return all_text

# Potential Repo: https://github.com/py-pdf/PyPDF2 (PyPDF2 library)