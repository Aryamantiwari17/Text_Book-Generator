#RAPTOR Indexing
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.mixture import GaussianMixture

def embed_chunks(chunks, model):
    return model.encode(chunks)

def cluster_embeddings(embeddings, min_clusters=2, max_clusters=10):
    n_samples = len(embeddings)
    n_clusters = min(n_samples, max_clusters)
    
    if n_samples < min_clusters:
        print(f"Warning: Only {n_samples} samples available. Clustering skipped.")
        return [0] * n_samples
    
    gmm = GaussianMixture(n_components=n_clusters, random_state=42)
    return gmm.fit_predict(embeddings)

def summarize_cluster(cluster_texts, max_length=100):
    combined_text = " ".join(cluster_texts)
    # Replace with your actual summarization model call
    summary = "Summary not implemented yet"  
    return summary[:max_length].strip()

def build_raptor_tree(embeddings, clusters, texts, depth=0, max_depth=3):
    if depth == max_depth or len(texts) <= 1:
        return {"type": "leaf", "texts": texts, "embedding": np.mean(embeddings, axis=0)}
    
    cluster_summaries = []
    for i in range(max(clusters) + 1):
        cluster_texts = [text for j, text in enumerate(texts) if clusters[j] == i]
        summary = summarize_cluster(cluster_texts)
        cluster_summaries.append(summary)
    
    summary_embeddings = embed_chunks(cluster_summaries, sbert_model)
    sub_clusters = cluster_embeddings(summary_embeddings)
    
    children = []
    for i in range(max(sub_clusters) + 1):
        child_indices = [j for j, c in enumerate(sub_clusters) if c == i]
        child_embeddings = [summary_embeddings[j] for j in child_indices]
        child_texts = [cluster_summaries[j] for j in child_indices]
        children.append(build_raptor_tree(child_embeddings, sub_clusters, child_texts, depth+1))